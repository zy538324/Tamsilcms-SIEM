#pragma once

#include <string>

namespace agent {

std::string DetectHostname();
std::string DetectOsName();

}  // namespace agent
