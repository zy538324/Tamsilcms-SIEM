#pragma once

#include "agent_config.h"

namespace agent {

bool SendInventorySnapshot(const Config& config);

}  // namespace agent
