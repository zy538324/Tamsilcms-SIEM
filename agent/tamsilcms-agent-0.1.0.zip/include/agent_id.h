#pragma once

#include <string>

namespace agent {

std::string GenerateEventId();

}  // namespace agent
