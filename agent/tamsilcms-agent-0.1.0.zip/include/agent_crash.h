#pragma once

namespace agent {

void InstallCrashHandler();

}  // namespace agent
