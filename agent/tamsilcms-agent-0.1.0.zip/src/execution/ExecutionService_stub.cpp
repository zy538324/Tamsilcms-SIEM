#include "ExecutionService_stub.h"
namespace agent_execution {
ExecutionResult ExecutionService::RunScript(const ScriptJob&) {
    ExecutionResult result{};
    // Stub: always return success
    return result;
}
}
