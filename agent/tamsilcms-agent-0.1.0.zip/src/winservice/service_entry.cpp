// Minimal stub for agent_winservice service entry
void ServiceEntry() {
    // Service logic stub
}
