// Minimal stub for agent_winservice main
#include <windows.h>
int main() {
    // Service entry stub
    return 0;
}
