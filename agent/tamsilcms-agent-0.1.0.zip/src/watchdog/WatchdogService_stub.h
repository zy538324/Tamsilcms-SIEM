#pragma once
namespace agent_watchdog {
class WatchdogService {
public:
    void Start() {}
    void Stop() {}
    void MonitorHealth() {}
    void CheckIntegrity() {}
};
}
