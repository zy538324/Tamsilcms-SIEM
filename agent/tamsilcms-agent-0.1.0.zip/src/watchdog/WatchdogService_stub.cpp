#include "WatchdogService_stub.h"
namespace agent_watchdog {
// Stub implementation
}
